public class Professor extends Person{

    Professor(String name, String surname) {
        super(name, surname);
    }


}
