import java.util.ArrayList;

public class Group {

    ArrayList<Student> arrayList = new ArrayList<Student>();

    Student student = new Student("anna", "shch",80.0, 40.1,false);
    Student student1 = new Student("maria","garna", 95.5, 98.0,false);
    Student student2 = new Student("anna","zencova", 93.4,60,false);

    public void meth() {
        arrayList.add(student);
        arrayList.add(student1);
        arrayList.add(student2);
        arrayList.add(new Student("vlad", "sidak", 74.7, 45.9,false));
    }

    public static void main(String[] args){
        Group group = new Group();
        group.meth();
    }
}
