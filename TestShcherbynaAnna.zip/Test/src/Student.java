import java.util.ArrayList;
import java.util.Scanner;

public class Student extends Person {

    public double averageMark;
    public double averageAttendance;
    boolean isPresent;

    Scanner scanner = new Scanner(System.in);

    Student(String name, String surname, double averageMark, double averageAttendance, boolean isPresent) {
        //super(name, surname);
        super(name, surname);
        this.averageMark = averageMark;
        this.averageAttendance = averageAttendance;
        this.isPresent = false;
    }

    public double getAverageMark() {
        return averageMark;
    }

    public void setAverageMark(double averageMark) {
        this.averageMark = averageMark;
    }

    @Override
    public String toString() {
        return "Student{" +
                "averageMark=" + averageMark +
                ", averageAttendance=" + averageAttendance +
                ", name='" + name + '\'' +
                ", surname='" + surname + '\'' +
                ", isPresent='" + isPresent + '\'' +
        '}';
    }

    public void printList(ArrayList<Student> arrayList){
        for (int i = 0; i<arrayList.size();i++){

            System.out.println(arrayList.get(i).toString());
        }
    }

    public String chooseCaptain(ArrayList<Student> arrayList){
        String n = "";
        double maxRating = 0;
        double rating = 0;
        int index=0;
        for (int i = 0; i<arrayList.size();i++){
            rating = arrayList.get(i).averageMark + arrayList.get(i).averageAttendance;
            if (rating>maxRating){
                maxRating = rating;
                index = i;
            }
        }
        System.out.println("Captain is - " + arrayList.get(index).name + " " + arrayList.get(index).surname + " with " + maxRating + " points") ;

        return n;
    }

    public void rollCall(ArrayList<Student > arrayList){
        int present = 0;
        System.out.println("If student is present - enter 1, if no - 0");
        for (int i = 0; i<arrayList.size();i++){
            System.out.print(arrayList.get(i).surname + " " + arrayList.get(i).name + " - ");
            present = scanner.nextInt();
            if (present == 1){
               // arrayList.add(i, new Student());
                arrayList.get(i).isPresent = true;
            }

            System.out.println();
        }

    }


  int i;
    public void selectMenu(ArrayList<Student> arrayList){

        while (scanner.hasNextInt()){
            i = scanner.nextInt();

            switch (i){
            case 1: printList(arrayList);
            break;
            case 2: chooseCaptain(arrayList);
            break;
            case 3: {
                rollCall(arrayList);
                printList(arrayList);
                break;
            }

             case 4: break;
         }

            System.out.println("To make your choice - enter a number:");

            System.out.println("1. See group");
            System.out.println("2. Choose a captain");
            System.out.println("3. Mark who is present today");
            System.out.println("4. Exit");
            System.out.println("Your choice - ");
        }

    }

    public static void main(String[] args){

        Student student = new Student("Anna", "Shcherbyna",80.0, 40.1,false);
        Student student1 = new Student("Maria","Garna", 95.5, 98.0,false);
        Student student2 = new Student("Anna","Zemtsova", 93.4,60,false);

        ArrayList<Student>  arrayList = new ArrayList<Student>();

            arrayList.add(student);
            arrayList.add(student1);
            arrayList.add(student2);
            arrayList.add(new Student("Vlad", "Sidak", 74.7, 45.9,false));

        student.printList(arrayList);

       System.out.println("To make your choice - enter a number:");
        System.out.println("1. See group");
        System.out.println("2. Choose a captain");
        System.out.println("3. Mark who is present today");
        System.out.println("4. Exit");
        System.out.println("Your choice - ");



        student.selectMenu(arrayList);

    }

}
